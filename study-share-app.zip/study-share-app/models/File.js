const mongoose = require('mongoose');

const SUBJECTS = ['Maths', 'Science', 'Hindi', 'Sanskrit', 'SST'];

const CommentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    username: {
      type: String,
      required: true
    },
    text: {
      type: String,
      required: [true, 'Comment text is required'],
      trim: true,
      maxlength: 1000
    }
  },
  { timestamps: true }
);

const FileSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: 150
    },
    subject: {
      type: String,
      required: [true, 'Subject is required'],
      enum: {
        values: SUBJECTS,
        message: `Subject must be one of: ${SUBJECTS.join(', ')}`
      }
    },
    originalName: {
      type: String,
      required: true
    },
    storedName: {
      type: String,
      required: true
    },
    path: {
      type: String,
      required: true
    },
    mimeType: {
      type: String,
      required: true
    },
    size: {
      type: Number,
      required: true
    },
    uploader: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      }
    ],
    comments: [CommentSchema]
  },
  { timestamps: true }
);

FileSchema.index({ subject: 1 });

module.exports = mongoose.model('File', FileSchema);
module.exports.SUBJECTS = SUBJECTS;
