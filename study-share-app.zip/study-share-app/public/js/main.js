/* Study Share App - frontend logic
   Handles auth (register/login/logout), fetching & rendering files by subject,
   uploads, like toggling, and comments. Uses fetch() against the /api routes.
   Auth token is stored in localStorage and also set as an httpOnly cookie by the server.
*/

const API_BASE = '/api';
const SUBJECTS = ['Maths', 'Science', 'Hindi', 'Sanskrit', 'SST'];

// ---------- Utilities ----------

function getToken() {
  return localStorage.getItem('token');
}

function setToken(token) {
  localStorage.setItem('token', token);
}

function clearToken() {
  localStorage.removeItem('token');
}

function authHeaders(extra = {}) {
  const token = getToken();
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

function showToast(message, isError = false) {
  const container = document.getElementById('toast-container');
  if (!container) {
    alert(message);
    return;
  }
  const toast = document.createElement('div');
  toast.className = `toast px-4 py-3 rounded-lg shadow-lg text-sm font-medium text-white ${
    isError ? 'bg-red-500' : 'bg-emerald-500'
  }`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function timeAgo(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Auth ----------

async function apiRegister(username, email, password) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Registration failed');
  return data;
}

async function apiLogin(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Login failed');
  return data;
}

async function apiLogout() {
  await fetch(`${API_BASE}/auth/logout`, {
    method: 'POST',
    headers: authHeaders()
  });
  clearToken();
}

async function apiGetMe() {
  const res = await fetch(`${API_BASE}/auth/me`, { headers: authHeaders() });
  if (!res.ok) return null;
  const data = await res.json();
  return data.user;
}

function requireAuthOrRedirect() {
  if (!getToken()) {
    window.location.href = '/login';
  }
}

// ---------- Files ----------

async function apiGetFiles(subject) {
  const url = subject ? `${API_BASE}/files?subject=${encodeURIComponent(subject)}` : `${API_BASE}/files`;
  const res = await fetch(url, { headers: authHeaders() });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Failed to load files');
  return data.files;
}

async function apiUploadFile(formData) {
  const res = await fetch(`${API_BASE}/files/upload`, {
    method: 'POST',
    headers: authHeaders(), // do NOT set Content-Type; browser sets multipart boundary
    body: formData
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Upload failed');
  return data.file;
}

async function apiToggleLike(fileId) {
  const res = await fetch(`${API_BASE}/files/${fileId}/like`, {
    method: 'PUT',
    headers: authHeaders()
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Failed to toggle like');
  return data;
}

async function apiAddComment(fileId, text) {
  const res = await fetch(`${API_BASE}/files/${fileId}/comments`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ text })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Failed to add comment');
  return data;
}

function downloadFileUrl(fileId) {
  return `${API_BASE}/files/${fileId}/download`;
}

// ---------- Dashboard rendering ----------

let currentSubjectFilter = '';
let cachedFiles = [];

function fileIcon(mimeType) {
  if (mimeType === 'application/pdf') return '📄';
  if (mimeType === 'text/plain') return '📝';
  if (mimeType === 'image/png') return '🖼️';
  return '📁';
}

function renderFiles(files) {
  const grid = document.getElementById('file-grid');
  if (!grid) return;

  if (!files.length) {
    grid.innerHTML = `<p class="col-span-full text-center text-slate-400 py-12">No study materials found for this subject yet. Be the first to upload one!</p>`;
    return;
  }

  grid.innerHTML = files
    .map(
      (f) => `
    <div class="file-card bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col" data-id="${f._id}">
      <div class="flex items-start justify-between mb-2">
        <span class="text-2xl">${fileIcon(f.mimeType)}</span>
        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-indigo-50 text-indigo-600">${f.subject}</span>
      </div>
      <h3 class="font-semibold text-slate-800 leading-snug mb-1 line-clamp-2">${escapeHtml(f.title)}</h3>
      <p class="text-xs text-slate-400 mb-3">
        by ${escapeHtml(f.uploader?.username || 'unknown')} · ${formatBytes(f.size)} · ${timeAgo(f.createdAt)}
      </p>
      <div class="mt-auto flex items-center justify-between pt-3 border-t border-slate-100">
        <div class="flex items-center gap-3">
          <button class="like-btn flex items-center gap-1 text-sm text-slate-500 hover:text-red-500 ${
            f.likedByMe ? 'liked text-red-500' : ''
          }" data-id="${f._id}">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="${
              f.likedByMe ? '#ef4444' : 'none'
            }" stroke="currentColor" stroke-width="2">
              <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/>
            </svg>
            <span class="like-count">${f.likeCount}</span>
          </button>
          <button class="comment-toggle flex items-center gap-1 text-sm text-slate-500 hover:text-indigo-500" data-id="${f._id}">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            <span class="comment-count">${f.commentCount}</span>
          </button>
        </div>
        <a href="${downloadFileUrl(f._id)}" class="text-sm font-medium text-indigo-600 hover:text-indigo-800">Download</a>
      </div>
      <div class="comments-section hidden mt-3 pt-3 border-t border-slate-100">
        <div class="comments-list space-y-2 max-h-40 overflow-y-auto scrollbar-thin mb-2"></div>
        <form class="comment-form flex gap-2" data-id="${f._id}">
          <input type="text" name="text" placeholder="Add a comment..." maxlength="1000"
            class="flex-1 text-sm border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-400" required />
          <button type="submit" class="text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg px-3 py-1.5">Post</button>
        </form>
      </div>
    </div>
  `
    )
    .join('');

  attachCardListeners(files);
}

function renderComments(fileId, comments) {
  const card = document.querySelector(`.file-card[data-id="${fileId}"]`);
  if (!card) return;
  const list = card.querySelector('.comments-list');
  if (!comments.length) {
    list.innerHTML = `<p class="text-xs text-slate-400">No comments yet.</p>`;
    return;
  }
  list.innerHTML = comments
    .map(
      (c) => `
    <div class="text-xs bg-slate-50 rounded-lg px-3 py-2">
      <span class="font-semibold text-slate-700">${escapeHtml(c.username || c.user?.username || 'user')}</span>
      <span class="text-slate-500"> · ${timeAgo(c.createdAt)}</span>
      <p class="text-slate-600 mt-0.5">${escapeHtml(c.text)}</p>
    </div>
  `
    )
    .join('');
}

function attachCardListeners(files) {
  document.querySelectorAll('.like-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      try {
        const { liked, likeCount } = await apiToggleLike(id);
        btn.classList.toggle('liked', liked);
        btn.classList.toggle('text-red-500', liked);
        btn.querySelector('svg').setAttribute('fill', liked ? '#ef4444' : 'none');
        btn.querySelector('.like-count').textContent = likeCount;
      } catch (err) {
        showToast(err.message, true);
      }
    });
  });

  document.querySelectorAll('.comment-toggle').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const card = document.querySelector(`.file-card[data-id="${id}"]`);
      const section = card.querySelector('.comments-section');
      const wasHidden = section.classList.contains('hidden');
      section.classList.toggle('hidden');
      if (wasHidden) {
        const file = files.find((f) => f._id === id);
        renderComments(id, file?.comments || []);
      }
    });
  });

  document.querySelectorAll('.comment-form').forEach((form) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = form.dataset.id;
      const input = form.querySelector('input[name="text"]');
      const text = input.value.trim();
      if (!text) return;
      try {
        const { comment, commentCount } = await apiAddComment(id, text);
        const card = document.querySelector(`.file-card[data-id="${id}"]`);
        card.querySelector('.comment-count').textContent = commentCount;
        const file = files.find((f) => f._id === id);
        if (file) file.comments.push(comment);
        renderComments(id, file?.comments || []);
        input.value = '';
      } catch (err) {
        showToast(err.message, true);
      }
    });
  });
}

async function loadFiles(subject = '') {
  try {
    cachedFiles = await apiGetFiles(subject);
    renderFiles(cachedFiles);
  } catch (err) {
    showToast(err.message, true);
  }
}

function initSubjectTabs() {
  const tabs = document.querySelectorAll('.subject-tab');
  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.remove('bg-indigo-600', 'text-white'));
      tabs.forEach((t) => t.classList.add('bg-white', 'text-slate-600'));
      tab.classList.add('bg-indigo-600', 'text-white');
      tab.classList.remove('bg-white', 'text-slate-600');
      currentSubjectFilter = tab.dataset.subject || '';
      loadFiles(currentSubjectFilter);
    });
  });
}

function initUploadForm() {
  const form = document.getElementById('upload-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const fileInput = form.querySelector('input[type="file"]');

    if (fileInput.files[0] && fileInput.files[0].size > 10 * 1024 * 1024) {
      showToast('File exceeds the 10MB size limit', true);
      return;
    }

    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Uploading...';

    try {
      await apiUploadFile(formData);
      showToast('File uploaded successfully!');
      form.reset();
      document.getElementById('upload-modal')?.classList.add('hidden');
      loadFiles(currentSubjectFilter);
    } catch (err) {
      showToast(err.message, true);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Upload';
    }
  });
}

function initModalToggle() {
  const openBtn = document.getElementById('open-upload-modal');
  const closeBtn = document.getElementById('close-upload-modal');
  const modal = document.getElementById('upload-modal');
  if (openBtn && modal) openBtn.addEventListener('click', () => modal.classList.remove('hidden'));
  if (closeBtn && modal) closeBtn.addEventListener('click', () => modal.classList.add('hidden'));
}

async function initNavUser() {
  const nameEl = document.getElementById('nav-username');
  const logoutBtn = document.getElementById('logout-btn');

  const user = await apiGetMe();
  if (!user) {
    window.location.href = '/login';
    return;
  }
  if (nameEl) nameEl.textContent = user.username;

  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await apiLogout();
      window.location.href = '/login';
    });
  }
}

// ---------- Page bootstraps ----------

async function initDashboardPage() {
  requireAuthOrRedirect();
  await initNavUser();
  initSubjectTabs();
  initUploadForm();
  initModalToggle();
  loadFiles();
}

function initLoginPage() {
  const form = document.getElementById('login-form');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value;
    const errorEl = document.getElementById('form-error');
    try {
      const data = await apiLogin(email, password);
      setToken(data.token);
      window.location.href = '/';
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.classList.remove('hidden');
      }
    }
  });
}

function initRegisterPage() {
  const form = document.getElementById('register-form');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = form.username.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value;
    const errorEl = document.getElementById('form-error');
    try {
      const data = await apiRegister(username, email, password);
      setToken(data.token);
      window.location.href = '/';
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.classList.remove('hidden');
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;
  if (page === 'dashboard') initDashboardPage();
  if (page === 'login') initLoginPage();
  if (page === 'register') initRegisterPage();
});
