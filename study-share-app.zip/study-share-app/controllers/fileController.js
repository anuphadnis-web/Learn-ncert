const path = require('path');
const fs = require('fs');
const File = require('../models/File');
const { SUBJECTS } = require('../models/File');

// @desc    Upload a new study material
// @route   POST /api/files/upload
// @access  Private
exports.uploadFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file was uploaded' });
    }

    const { title, subject } = req.body;

    if (!title || !subject) {
      // Clean up the orphaned file from disk since we're rejecting the request
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ success: false, message: 'Title and subject are required' });
    }

    if (!SUBJECTS.includes(subject)) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({
        success: false,
        message: `Subject must be one of: ${SUBJECTS.join(', ')}`
      });
    }

    const file = await File.create({
      title,
      subject,
      originalName: req.file.originalname,
      storedName: req.file.filename,
      path: `/uploads/${req.file.filename}`,
      mimeType: req.file.mimetype,
      size: req.file.size,
      uploader: req.user._id
    });

    const populated = await file.populate('uploader', 'username');

    res.status(201).json({ success: true, file: populated });
  } catch (err) {
    console.error(err);
    if (req.file) fs.unlink(req.file.path, () => {});
    res.status(500).json({ success: false, message: 'Server error during file upload' });
  }
};

// @desc    Get all files, optionally filtered by subject, with uploader/like/comment info
// @route   GET /api/files?subject=Maths
// @access  Private
exports.getFiles = async (req, res) => {
  try {
    const filter = {};
    if (req.query.subject) {
      if (!SUBJECTS.includes(req.query.subject)) {
        return res.status(400).json({ success: false, message: 'Invalid subject filter' });
      }
      filter.subject = req.query.subject;
    }

    const files = await File.find(filter)
      .populate('uploader', 'username')
      .populate('comments.user', 'username')
      .sort({ createdAt: -1 });

    // Shape response to include like count and whether current user has liked it
    const shaped = files.map((f) => ({
      _id: f._id,
      title: f.title,
      subject: f.subject,
      originalName: f.originalName,
      path: f.path,
      mimeType: f.mimeType,
      size: f.size,
      uploader: f.uploader,
      likeCount: f.likes.length,
      likedByMe: req.user ? f.likes.some((id) => id.equals(req.user._id)) : false,
      commentCount: f.comments.length,
      comments: f.comments,
      createdAt: f.createdAt
    }));

    res.status(200).json({ success: true, count: shaped.length, files: shaped });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while fetching files' });
  }
};

// @desc    Get a single file's metadata (with comments)
// @route   GET /api/files/:id
// @access  Private
exports.getFile = async (req, res) => {
  try {
    const file = await File.findById(req.params.id)
      .populate('uploader', 'username')
      .populate('comments.user', 'username');

    if (!file) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    res.status(200).json({
      success: true,
      file: {
        ...file.toObject(),
        likeCount: file.likes.length,
        likedByMe: file.likes.some((id) => id.equals(req.user._id))
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while fetching file' });
  }
};

// @desc    Download a file by id
// @route   GET /api/files/:id/download
// @access  Private
exports.downloadFile = async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    const absolutePath = path.join(__dirname, '..', 'public', 'uploads', file.storedName);

    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ success: false, message: 'File missing from storage' });
    }

    res.download(absolutePath, file.originalName);
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while downloading file' });
  }
};

// @desc    Toggle like status on a file for the current user
// @route   PUT /api/files/:id/like
// @access  Private
exports.toggleLike = async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    const userId = req.user._id;
    const alreadyLiked = file.likes.some((id) => id.equals(userId));

    if (alreadyLiked) {
      file.likes = file.likes.filter((id) => !id.equals(userId));
    } else {
      file.likes.push(userId);
    }

    await file.save();

    res.status(200).json({
      success: true,
      liked: !alreadyLiked,
      likeCount: file.likes.length
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while toggling like' });
  }
};

// @desc    Add a comment to a file
// @route   POST /api/files/:id/comments
// @access  Private
exports.addComment = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, message: 'Comment text is required' });
    }

    const file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    const comment = {
      user: req.user._id,
      username: req.user.username,
      text: text.trim()
    };

    file.comments.push(comment);
    await file.save();

    const newComment = file.comments[file.comments.length - 1];

    res.status(201).json({ success: true, comment: newComment, commentCount: file.comments.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while adding comment' });
  }
};

// @desc    Get all comments for a file
// @route   GET /api/files/:id/comments
// @access  Private
exports.getComments = async (req, res) => {
  try {
    const file = await File.findById(req.params.id).populate('comments.user', 'username');
    if (!file) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    res.status(200).json({ success: true, comments: file.comments });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error while fetching comments' });
  }
};
