const express = require('express');
const router = express.Router();
const multer = require('multer');

const {
  uploadFile,
  getFiles,
  getFile,
  downloadFile,
  toggleLike,
  addComment,
  getComments
} = require('../controllers/fileController');

const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Wrap multer so its errors (file too large, bad type) return clean JSON
const handleUpload = (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ success: false, message: 'File exceeds the 10MB size limit' });
      }
      return res.status(400).json({ success: false, message: err.message });
    } else if (err) {
      return res.status(400).json({ success: false, message: err.message });
    }
    next();
  });
};

router.use(protect); // all file routes require authentication

router.post('/upload', handleUpload, uploadFile);
router.get('/', getFiles);
router.get('/:id', getFile);
router.get('/:id/download', downloadFile);
router.put('/:id/like', toggleLike);
router.post('/:id/comments', addComment);
router.get('/:id/comments', getComments);

module.exports = router;
